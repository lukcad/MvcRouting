﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Areas.Products.Controllers
{
  public class ProductsController : Controller
  {
    // GET: Products/Products
    public ActionResult ShowRecent()
    {
      return View();
    }

    public ActionResult ShowArchive()
    {
      return View();
    }
  }
}