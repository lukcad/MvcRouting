﻿using $safeprojectname$.Constraints;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace $safeprojectname$
{
  public class RouteConfig
  {
    /// <summary>
    /// This register routes calss contains my own custom route 
    /// which has not only new route but also has constraints
    /// </summary>
    /// <param name="routes"></param>
    public static void RegisterRoutes(RouteCollection routes)
    {
      routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
      // this custom route lets me execute information from this path: /Archive/12-12-2016
      routes.MapRoute(
        name: "Archive",
        url: "Archive/{entryDate}",
        defaults: new { controller = "Blog", action = "Archive" },
        constraints: new
        {
          entryDate = @"\d{2}.\d{2}.\d{4}",         // constraint which defines format of parameter by reqular expression
          method = new HttpMethodConstraint("GET") // constraint which restrict POST method
        }
        );

      routes.MapRoute(
        name: "Secured",
        url: "Secured/Vip/Contact",
        defaults: new { controller = "Vip", action = "Contact" },
        constraints: new
        {
          Auth = new AuthenticatedConstraint()      // constraint prevents a request from matching a route when there request is not made by authenticated user.
        }
       );

      routes.MapRoute(
          name: "Default",
          url: "{controller}/{action}/{id}",
          defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
      );


    }
  }
}
